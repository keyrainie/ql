﻿using ECommerce.Entity.Passport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Facade.Passport.Partner
{
    ///// <summary>
    ///// 微信登陆
    ///// </summary>
    //public class PartnerWechat
    //{
    //    /// <summary>
    //    /// 设置请求参数
    //    /// </summary>
    //    /// <param name="context">第三方登录上下文</param>
    //    public override void SetRequestParam(PartnerContext context)
    //    {
    //    }
    //}
}
