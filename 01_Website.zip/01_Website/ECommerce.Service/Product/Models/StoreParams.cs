﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Facade.Product.Models
{
    public class StoreParams
    {
        public string CurrentSysNo { get; set; }
    }
}
