﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.SOPipeline.Impl
{
    public class NeweggSpecialCalculator : ICalculate
    {
        public void Calculate(ref OrderInfo order)
        {
        }
    }
}
