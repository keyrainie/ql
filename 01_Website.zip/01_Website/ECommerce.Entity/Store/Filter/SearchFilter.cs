﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Entity.Store.Filter
{
    public class SearchFilter
    {
        public int SellerSysNo { get; set; }
        public string SearchKey { get; set; }
    }
}
