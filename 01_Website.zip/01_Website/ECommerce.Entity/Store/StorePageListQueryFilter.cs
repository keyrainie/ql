﻿using ECommerce.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Entity.Store
{
    public class StorePageListQueryFilter : QueryFilter
    {
        public string PageName { get; set; }
    }
}
