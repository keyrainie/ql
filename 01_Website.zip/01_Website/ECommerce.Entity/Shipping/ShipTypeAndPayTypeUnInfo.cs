﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Entity.Shipping
{
    public class ShipTypeAndPayTypeUnInfo
    {
        public int SysNo { get; set; }

        public int ShipTypeSysNo { get; set; }

        public int PayTypeSysNo { get; set; }
    }
}
