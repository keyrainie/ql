﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Entity.Product
{
   public class ProductPropertyListInfo
    {
        /// <summary>
        /// 获取或设置商品属性组信息
        /// </summary>
       public List<ProductPropertyInfo> PropertyList { get; set; }
    }
}
