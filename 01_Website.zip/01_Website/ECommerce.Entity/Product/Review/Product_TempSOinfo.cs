﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Entity.Product
{
    public class Product_TempSOinfo
    {
        public int SOSysNo
        {
            get;
            set;
        }

        public string ProductCode
        {
            get;
            set;
        }

        public int SoStatus { get; set; }
    }
}
