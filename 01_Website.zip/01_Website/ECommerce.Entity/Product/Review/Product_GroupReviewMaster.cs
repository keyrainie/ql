﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECommerce.Entity.Product.Review
{
    public class Product_GroupReviewMaster
    {
    }
}
