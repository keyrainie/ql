﻿namespace ECommerce.Entity.Product
{
    public enum ConsultQueryType
    {
        ByProduct = 0,
        ByCustomer = 1,
        ByUserSpace = 2,
        ByNone = 3,
    }
}
